# Deliberate Development skill set

Three interoperable skills for non-trivial software work:

1. `ground-work` — clarify requirements and verify relevant current technical context.
2. `shape-work` — design, de-risk, and create behavioral slices.
3. `execute-work` — estimate/timebox a ready slice, implement/validate it, control scope, and checkpoint/close.

They share a task-local state model. If the project has no existing convention, task state lives under:

```text
.work/<task-id>/
  STATUS.md
  SPEC.md
  CURRENT_STATE.md
  ARCHITECTURE.md
  PLAN.md
```

The files are the interoperability layer between sessions and models. A new agent should reconstruct state from them rather than relying on chat history.

## Installation

Each skill is packaged separately as `skill.zip` under `dist/<skill-name>/skill.zip`. Install/upload those separately. The source bundle containing all three skills is for inspection or version control, not as one multi-skill upload.

## Scripts

- `ground-work/scripts/init_work.py`: initialize the five task files from templates.
- `scripts/validate_work.py` in each skill: check required files, stage values, slice IDs/statuses, and `current_slice` consistency.

The scripts intentionally handle only deterministic bookkeeping. Requirements, architecture, risk, slicing, estimation, and implementation decisions remain model-driven.

## Design choices

The instructions are written for strong coding/reasoning agents such as GPT-5.6 Sol and Claude Opus 5.5:

- outcome/constraint/exit-criteria focused rather than chain-of-thought scripting;
- lean control-plane `SKILL.md` files with detailed methodology in references;
- explicit stop/return gates and scope boundaries;
- durable artifact state rather than conversational memory;
- specific anti-patterns and a few contrastive examples at hard judgment boundaries;
- no generic "think harder" instructions.

## Source grounding

The bundled references cite the public material used in the workflow: Fowler on Specification by Example / Given-When-Then / TDD; Wake on INVEST and splitting; Singer's Shape Up chapters on shaping, boundaries, risks and rabbit holes; Spolsky on Evidence Based Scheduling; Newport on time blocking; and Beck's Canon TDD.

Where the source set did not directly establish a method—especially unfamiliar-codebase reconnaissance, a block stop condition, and structured close/reconciliation—the reference files label the skillset policy as a derived adaptation rather than attributing it to those sources.
