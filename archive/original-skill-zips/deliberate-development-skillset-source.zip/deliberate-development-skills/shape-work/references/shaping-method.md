# Shaping method and provenance

## Source-derived guidance

### Story quality and splitting

Public sources:
- Bill Wake, INVEST in Good Stories, and SMART Tasks: https://xp123.com/invest-in-good-stories-and-smart-tasks/
- Bill Wake, Independent Stories in the INVEST Model: https://xp123.com/independent-stories-in-the-invest-model/
- Bill Wake, Twenty Ways to Split Stories: https://xp123.com/twenty-ways-to-split-stories/

Use independence, value/behavior, estimability, smallness, and testability as diagnostics rather than as a ritual. Prefer narrow end-to-end behavior, base cases, simpler variants, or explicit research spikes over horizontal technical decomposition.

### Boundaries and risk

Public sources:
- Ryan Singer, Principles of Shaping: https://basecamp.com/shapeup/1.1-chapter-02
- Ryan Singer, Set Boundaries: https://basecamp.com/shapeup/1.2-chapter-03
- Ryan Singer, Risks and Rabbit Holes: https://basecamp.com/shapeup/1.4-chapter-05

Shape work so it is rough enough to leave implementation latitude, solved enough to avoid major unanswered design questions, and bounded enough to avoid open-ended scope. Identify rabbit holes and material unknowns before commitment.

## Source tension retained

### Up-front decomposition

Joel Spolsky's Evidence Based Scheduling favors breaking work into small tasks up front. Shape Up emphasizes that many tasks are discovered during implementation and warns against task estimates that hide uncertainty.

Policy for this skillset: define behavioral slices up front, but do not fabricate a complete implementation-task inventory. Decompose implementation details for the current slice as they become knowable.

### Appetite vs estimate

Shape Up's appetite is a time-budget decision, not a prediction. Keep it distinct from an estimate.

### Hard-coding/stubbing

Wake/Singer may use stubbing or reduced versions to make progress. TDD sources reject faking the behavior under test.

Policy: stub deferred/external dependencies when needed to enable a vertical slice; never fake the behavior the current acceptance test is intended to verify.

## Contrastive derived examples

Good slice: `Authenticated user can change a valid display name and see it persisted after reload.`

Bad slice: `Implement backend for profile editing.`

Good spike: `30-minute investigation: verify whether provider X supports the required refresh-token flow; output is yes/no plus the architectural consequence.`

Bad estimate disguised as certainty: `Implement provider X integration - 90 minutes` when refresh-token support is still unknown.
