---
name: shape-work
description: Turn grounded software-task knowledge into a bounded architecture, explicit risks, and independently verifiable behavioral slices. Use after grounding or when asked to design, de-risk, break down, or slice a non-trivial software task. Read SPEC.md and CURRENT_STATE.md, maintain ARCHITECTURE.md, PLAN.md, and STATUS.md, investigate material unknowns before commitment, and create behavior-focused slices without pretending all implementation tasks are knowable up front.
---

# Shape Work

Turn the verified desired state and current state into a sufficiently solved, bounded path to implementation.

## Core invariants

- `SPEC.md` says what should be true. `CURRENT_STATE.md` says what is true now. `ARCHITECTURE.md` says how the change is intended to work. `PLAN.md` says in what behavioral increments it will be delivered.
- Do not silently change requirements to fit a convenient architecture.
- Do not silently rewrite current-state facts when design assumptions change.
- Size and uncertainty are separate problems: slice large work; de-risk uncertain work.
- Future slices describe behavior. Do not decompose the entire project into speculative implementation tasks.
- Newly discovered material facts belong in `CURRENT_STATE.md`; requirement changes belong in `SPEC.md`.

## Enter or resume

1. Read applicable project instructions.
2. Read `STATUS.md`, then `SPEC.md` and `CURRENT_STATE.md`.
3. Read existing `ARCHITECTURE.md` and `PLAN.md` if present.
4. Resume from the concrete `Next` action. Do not repeat completed design work unless new evidence invalidates it.
5. Run `scripts/validate_work.py <task-workspace>` when execution is available if state consistency is uncertain.

For the shared task-file contract, read `references/task-state.md`.

## Architecture

Produce only as much architecture as the task needs.

- Start from the desired behavior and verified current state.
- Identify affected components, interfaces, data/control flow, persistence, and constraints.
- Consider alternatives when there is a real decision, not to manufacture option lists.
- Record the chosen approach, meaningful rejected alternatives, and reasons in `ARCHITECTURE.md`.
- Prefer the simplest architecture that satisfies the current scope and project conventions.
- Do not add future-facing abstractions unless the current scope needs them.

## De-risk

Before committing to slices, expose risks and rabbit holes.

Investigate an unknown now when it could materially change:

- architecture;
- feasibility;
- slice boundaries;
- external behavior;
- data migration or permissions;
- the credibility of the estimate for the first executable slice.

If the unknown is itself the work, create a bounded investigation/spike with a concrete question and expected decision. Do not disguise an uncertain integration as a precise implementation estimate.

## Slice

Maintain slices in `PLAN.md` as the single source of truth.

Each slice should have:

- stable ID (`S1`, `S2`, ...);
- short behavioral title;
- status: `candidate`, `not-ready`, `ready`, `in-progress`, `blocked`, `done`, or `dropped`;
- observable behavior/outcome;
- done conditions or acceptance examples;
- dependencies and material unknowns.

Prefer the smallest useful end-to-end behavior that can be independently verified.

Do not use horizontal technical layers as slices merely because all layers require changes.

**Good derived example**

`S1 - Authenticated user can submit a valid profile-name change and see the persisted result.`

**Bad derived example**

`S1 - Database changes; S2 - backend; S3 - frontend; S4 - tests.`

Future slices stay behavioral. Add detailed implementation steps only when a slice becomes current during execution.

## Source conflicts and chosen policies

Read `references/shaping-method.md` when a source tension matters. In particular:

- Do not require a complete up-front implementation task inventory merely to estimate later work.
- Keep appetite/time allocation distinct from estimate; `shape-work` does not turn a time budget into a prediction.
- Stubbing deferred dependencies may be acceptable to enable a vertical slice; do not fake the behavior that the current acceptance test is meant to verify.

## Checkpoint and interruption

Persist design decisions in `ARCHITECTURE.md` and slice definitions in `PLAN.md` before updating `STATUS.md`.

When stopping mid-stage, `STATUS.md` must contain one concrete next action that identifies the decision/question and the artifact section to update. Avoid vague next actions such as "continue architecture."

## Exit criteria

A task is ready for `execute-work` when:

- architecture is sufficiently decided for the current scope;
- material technical risks for the first slice are resolved or explicitly represented as a spike/blocker;
- `PLAN.md` contains at least one `ready` slice;
- the current slice has observable done conditions;
- `STATUS.md` points to the ready slice or exact blocker.

If these conditions are not met, remain in `shape-work` rather than passing ambiguity downstream.
