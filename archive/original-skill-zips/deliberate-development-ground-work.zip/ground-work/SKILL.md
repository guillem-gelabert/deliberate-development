---
name: ground-work
description: Establish requirements and relevant technical context before solution design for non-trivial software work. Use when starting or resuming a ticket, bug, feature, integration, unfamiliar code path, or requirement that needs clarification. Inspect project instructions and relevant sources, maintain task-local SPEC.md, CURRENT_STATE.md, and STATUS.md, distinguish verified facts from assumptions, surface material ambiguities, and stop before architecture or slicing except to record constraints.
---

# Ground Work

Establish enough verified knowledge about both the requested change and the existing system to support sound design. Do not design the solution yet.

## Core invariants

- Treat task files as authoritative workflow state; do not rely on conversation memory.
- Treat `SPEC.md` as what should become true and `CURRENT_STATE.md` as what is true now. Do not mix them.
- Distinguish verified facts, conservative inference, assumptions, and open questions.
- Investigate context relevant to this task; do not document the whole codebase.
- Ask the user only when a material ambiguity cannot be resolved from available project, code, test, documentation, or read-only research sources.
- Do not proceed while an unresolved answer could materially change acceptance criteria, externally visible behavior, scope, irreversible architecture, permissions, or data handling.

## Enter or resume

1. Read applicable project instructions such as `AGENTS.md`, `CLAUDE.md`, nested equivalents, and existing project conventions.
2. Locate the task workspace. Follow an existing project convention if present; otherwise use `.work/<task-id>/`.
3. If no task workspace exists, initialize it with `scripts/init_work.py` when execution is available; otherwise create the same files manually from the templates in `assets/templates/`.
4. Read `STATUS.md`. Resume its concrete `Next` action instead of restarting completed work.
5. Read existing `SPEC.md` and `CURRENT_STATE.md` before investigating further.

For the shared task-file contract and resume rules, read `references/task-state.md`.

## Track A: understand the task

Establish the requested behavior before implementation details.

- Read the ticket/request and linked requirement material.
- Identify explicit ambiguities and actively search for hidden ones: undefined terms, missing states, contradictory interpretations, boundary cases, failure behavior, permissions, migration/backward-compatibility implications, and assumptions that would materially change implementation.
- Resolve questions through available evidence: colleagues/user input when genuinely required, product/domain documentation, existing behavior, tests, and research.
- Convert confirmed behavior into concrete acceptance criteria or examples where useful.
- Record unresolved but non-blocking assumptions explicitly; never silently promote them to facts.
- Maintain `SPEC.md` continuously rather than writing it only at the end.

## Track B: understand the technical context

Establish only the current technical context needed to reason about the task.

Inspect relevant:

- code paths and tests;
- configuration and runtime boundaries;
- service-to-service integrations;
- package/product APIs and official documentation;
- data flow and persistence;
- analogous implementations and local patterns;
- constraints that could affect the solution.

Search beyond initially named files when doing so could materially change the understanding. Keep the investigation bounded to the task.

Record verified findings in `CURRENT_STATE.md`, including source locations or links that let another agent re-check them.

## Evidence discipline

Use these meanings when uncertainty matters:

- **Verified**: observed directly in code, tests, runtime/configuration, authoritative documentation, or confirmed requirement input.
- **Inferred**: a conservative conclusion from verified evidence, not directly confirmed.
- **Assumed**: a provisional belief needed to reason further.
- **Open**: not yet known.

Do not present inferred or assumed behavior as current-state fact.

## Checkpoint and interruption

After a meaningful investigation or decision:

1. Persist substantive knowledge in `SPEC.md` or `CURRENT_STATE.md` first.
2. Keep unfinished reasoning explicitly provisional.
3. Update `STATUS.md` with the current stage/step, artifact states, open blockers, and one concrete `Next` action.
4. If stopping mid-stage, leave the workspace resumable by a different agent with no chat history.

## Exit criteria

Grounding is complete enough to hand off to `shape-work` when:

- the desired behavior and scope are concrete enough to design against;
- the relevant present system behavior and interfaces are understood well enough to avoid speculative architecture;
- material unresolved questions are either resolved or explicitly marked as blockers/spikes;
- `SPEC.md` and `CURRENT_STATE.md` reflect the latest verified knowledge;
- `STATUS.md` points to `shape-work` or to the exact unresolved action preventing it.

Do not create `ARCHITECTURE.md` decisions or behavioral slices here beyond placeholders created by initialization.

## Grounding reference

Read `references/grounding-method.md` when deciding how concrete examples should shape requirements or when the boundary between verified context and speculation is unclear.
