---
stage: ground-work
step: requirement-research
status: in-progress
current_slice:
updated: {{DATE}}
---

# Status

## Artifact state

- SPEC.md: draft
- CURRENT_STATE.md: draft
- ARCHITECTURE.md: not-started
- PLAN.md: not-started

## Open

- None recorded yet.

## Next

Read the task/request, identify material ambiguities, and update `SPEC.md`.
