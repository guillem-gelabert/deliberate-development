# Plan

> Not started. `shape-work` owns slice creation.

## Slices

## Discovered work
