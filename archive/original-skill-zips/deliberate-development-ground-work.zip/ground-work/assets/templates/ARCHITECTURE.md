# Architecture

> Not started. `shape-work` owns this artifact.

## Goal

## Proposed change

## Data / control flow

## Components affected

## Interfaces

## Decisions

## Alternatives considered

## Risks / rabbit holes

## Open technical questions

## Out of scope
