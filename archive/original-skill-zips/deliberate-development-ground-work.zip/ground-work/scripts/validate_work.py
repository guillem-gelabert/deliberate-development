#!/usr/bin/env python3
"""Validate deliberate-development task state using only the Python standard library."""
from __future__ import annotations

import argparse
from pathlib import Path
import re
import sys

REQUIRED = ["STATUS.md", "SPEC.md", "CURRENT_STATE.md", "ARCHITECTURE.md", "PLAN.md"]
STAGES = {"ground-work", "shape-work", "execute-work"}
SLICE_STATES = {"candidate", "not-ready", "ready", "in-progress", "blocked", "done", "dropped"}


def frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        return {}
    end = text.find("\n---\n", 4)
    if end < 0:
        return {}
    data = {}
    for line in text[4:end].splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            data[k.strip()] = v.strip()
    return data


def slices(text: str) -> dict[str, str | None]:
    result: dict[str, str | None] = {}
    matches = list(re.finditer(r"^##\s+(S\d+)\b.*$", text, re.MULTILINE))
    for i, match in enumerate(matches):
        sid = match.group(1)
        start = match.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = text[start:end]
        sm = re.search(r"^\*\*Status:\*\*\s*`?([a-z-]+)`?\s*$", body, re.MULTILINE)
        if sid in result:
            result[sid] = "__duplicate__"
        else:
            result[sid] = sm.group(1) if sm else None
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("workspace", help="path containing STATUS.md, SPEC.md, CURRENT_STATE.md, ARCHITECTURE.md, PLAN.md")
    args = parser.parse_args()
    root = Path(args.workspace)
    errors: list[str] = []
    warnings: list[str] = []

    for name in REQUIRED:
        if not (root / name).is_file():
            errors.append(f"missing {name}")
    if errors:
        for e in errors:
            print(f"ERROR: {e}")
        return 1

    status_text = (root / "STATUS.md").read_text(encoding="utf-8")
    fm = frontmatter(status_text)
    if not fm:
        errors.append("STATUS.md has no parseable YAML-style frontmatter")
    stage = fm.get("stage", "")
    if stage and stage not in STAGES:
        errors.append(f"unknown stage: {stage}")

    plan_text = (root / "PLAN.md").read_text(encoding="utf-8")
    found = slices(plan_text)
    for sid, state in found.items():
        if state == "__duplicate__":
            errors.append(f"duplicate slice id: {sid}")
        elif state is None:
            warnings.append(f"{sid} has no **Status:** field")
        elif state not in SLICE_STATES:
            errors.append(f"{sid} has unknown status: {state}")

    current = fm.get("current_slice", "").strip()
    if current:
        if current not in found:
            errors.append(f"STATUS current_slice {current} does not exist in PLAN.md")
        elif found.get(current) == "done":
            warnings.append(f"STATUS current_slice {current} is already done")

    for e in errors:
        print(f"ERROR: {e}")
    for w in warnings:
        print(f"WARN: {w}")
    if errors:
        return 1
    print("OK: task workspace is structurally consistent")
    return 0


if __name__ == "__main__":
    sys.exit(main())
