#!/usr/bin/env python3
"""Initialize a task-local deliberate-development workspace."""
from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path
import re
import sys

FILES = ["STATUS.md", "SPEC.md", "CURRENT_STATE.md", "ARCHITECTURE.md", "PLAN.md"]


def safe_task_id(value: str) -> str:
    value = value.strip()
    if not value or not re.fullmatch(r"[A-Za-z0-9._-]+", value):
        raise argparse.ArgumentTypeError("task id may contain only letters, digits, '.', '_' and '-'")
    return value


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("task_id", type=safe_task_id)
    parser.add_argument("--root", default=".work", help="workspace root (default: .work)")
    parser.add_argument("--force", action="store_true", help="overwrite existing template files")
    args = parser.parse_args()

    skill_root = Path(__file__).resolve().parent.parent
    templates = skill_root / "assets" / "templates"
    target = Path(args.root) / args.task_id
    target.mkdir(parents=True, exist_ok=True)

    created = []
    skipped = []
    for name in FILES:
        src = templates / name
        dst = target / name
        if dst.exists() and not args.force:
            skipped.append(name)
            continue
        text = src.read_text(encoding="utf-8").replace("{{DATE}}", date.today().isoformat())
        dst.write_text(text, encoding="utf-8")
        created.append(name)

    print(f"Workspace: {target}")
    if created:
        print("Created: " + ", ".join(created))
    if skipped:
        print("Preserved existing: " + ", ".join(skipped))
    return 0


if __name__ == "__main__":
    sys.exit(main())
