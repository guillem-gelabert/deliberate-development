# Shared task-state contract

Use project conventions for task documentation when they exist. Otherwise use:

```text
.work/<task-id>/
  STATUS.md
  SPEC.md
  CURRENT_STATE.md
  ARCHITECTURE.md
  PLAN.md
```

## Semantic ownership

- `SPEC.md`: desired behavior, acceptance criteria, scope, assumptions, open requirement questions.
- `CURRENT_STATE.md`: verified relevant present behavior, code paths, integrations, APIs, constraints, and re-checkable sources.
- `ARCHITECTURE.md`: intended solution, affected components/interfaces, decisions, alternatives, risks, out-of-scope design.
- `PLAN.md`: behavioral slices, slice statuses, current-slice implementation checklist, discovered work, optional estimate/actual metadata.
- `STATUS.md`: workflow cursor only: stage, step, artifact state, blockers, and one concrete next action. Do not duplicate substantive research here.

## Artifact states

Use: `not-started`, `draft`, `blocked`, `review-needed`, `complete`, `stale`.

## Slice states

Use: `candidate`, `not-ready`, `ready`, `in-progress`, `blocked`, `done`, `dropped`.

## Resume protocol

1. Reconstruct state from files, not conversation memory.
2. Read `STATUS.md` and the authoritative documents for the current stage.
3. Check whether the cursor agrees with the artifacts.
4. Resume the concrete `Next` action.
5. Do not redo completed work unless new evidence invalidates it.

## Checkpoint protocol

1. Update substantive artifacts first.
2. Mark provisional reasoning as provisional.
3. Record unresolved questions/blockers.
4. Update artifact/slice states.
5. Write one concrete `Next` action that names the action and target artifact/section.
