# Grounding method and provenance

## Source-derived guidance

### Specification by Example / Given-When-Then

Primary public sources:
- Martin Fowler, Specification By Example: https://martinfowler.com/bliki/SpecificationByExample.html
- Martin Fowler, Given When Then: https://martinfowler.com/bliki/GivenWhenThen.html

Use concrete examples to make desired behavior precise. Given/When/Then is useful when precondition, action, and observable result matter. Examples can expose missing cases and ambiguous language, but examples do not replace all requirements or design decisions.

### Shaping/problem understanding

Supporting public source:
- Ryan Singer, Principles of Shaping: https://basecamp.com/shapeup/1.1-chapter-02

Carry forward the idea that work should become sufficiently solved and bounded before building, while avoiding premature solution design during grounding.

## Derived adaptation for this skillset

The public corpus used for this workflow is weak on unfamiliar-codebase reconnaissance. The following are explicit adaptations, not claims from the sources above:

- Separate requirement knowledge from technical-context knowledge.
- Inspect relevant code, tests, configuration, integrations, APIs, and analogous implementations before architecture.
- Record re-checkable present-state facts in `CURRENT_STATE.md`.
- Bound reconnaissance to context that could materially affect the task.

## Contrastive derived examples

### Requirement

Good: `Given an authenticated user with a valid display name, when they submit the profile form, then the persisted name is returned on reload.`

Bad: `Profile editing should work correctly.`

The first makes conditions and observable behavior testable; the second hides ambiguity.

### Current state

Good: `src/profile/api.ts calls PUT /v2/profile from saveProfile(); ProfileForm.vue invokes it on submit. Verified in code and test X.`

Bad: `The frontend probably saves through the profile service.`

The first is re-checkable; the second converts inference into fact.
