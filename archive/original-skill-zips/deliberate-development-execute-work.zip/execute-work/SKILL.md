---
name: execute-work
description: Execute and close a ready software slice with explicit estimate/timebox discipline, appropriate test-first development, scope control, and durable task-state updates. Use when a behavioral slice is ready to implement or when resuming implementation. Read STATUS.md, SPEC.md, CURRENT_STATE.md, ARCHITECTURE.md, and PLAN.md; keep estimate distinct from time allocation and deadline; implement the current slice, capture discoveries, reconcile authoritative docs, and leave a concrete next action.
---

# Execute Work

Execute one ready behavioral slice without silently expanding scope, and leave the task state accurate enough for another agent to continue.

## Core invariants

- Estimate is a prediction. Timebox/appetite is an allocation decision. Deadline is an external commitment. Never silently substitute one for another.
- `PLAN.md` is the source of truth for slices and the current slice's implementation checklist.
- Work only on the current slice unless a newly discovered issue is required for that slice to be valid.
- Do not implement against a materially unclear requirement or invalid architecture; return to `ground-work` or `shape-work` instead.
- Persist changed knowledge in the authoritative task document, not only in chat or `STATUS.md`.
- Do not fake the behavior under test. Faking/stubbing an external or deferred dependency may be acceptable when the slice still verifies its intended behavior.

## Enter or resume

1. Read applicable project instructions.
2. Read `STATUS.md`, `PLAN.md`, `SPEC.md`, `CURRENT_STATE.md`, and `ARCHITECTURE.md` as relevant to the current slice.
3. Confirm the current slice exists and is `ready` or `in-progress`. If not, return to `shape-work`.
4. Run `scripts/validate_work.py <task-workspace>` when execution is available if state consistency is uncertain.
5. Resume the concrete `Next` action; do not restart the slice because the chat/session changed.

For the task-file contract, read `references/task-state.md`.

## Prepare the current slice

Before coding:

- restate the slice's observable outcome and done conditions;
- identify immediate implementation/test steps only for this slice;
- estimate the slice after enough uncertainty has been removed to make the estimate meaningful;
- record the estimate in the slice when useful to calibration;
- define the current work block's goal and stop/reassessment condition without treating the block as a deadline.

If the slice is too uncertain to estimate credibly, return to `shape-work` and de-risk or re-slice it.

## Implement

Use the project's established testing conventions. When behavior is testable with TDD, use a small inner loop:

1. Maintain a short test list for the current behavior.
2. Select one concrete runnable behavior.
3. Make the relevant test fail for the intended reason.
4. Make it pass with the smallest sound implementation.
5. Inspect for an actual refactoring opportunity; refactor when it improves the design, but do not refactor performatively.
6. Repeat.

For work not suited to test-first development, define and perform the appropriate validation before declaring the slice done.

Read `references/execution-method.md` for source-derived TDD, estimation, and conflict policies.

## Scope control during implementation

Classify discoveries immediately:

- **Required for current slice**: handle now if necessary for the slice's done conditions.
- **Requirement change/ambiguity**: update `SPEC.md`; stop or return to `ground-work` if material.
- **Current-state discovery**: update `CURRENT_STATE.md`; re-evaluate architecture if material.
- **Architecture invalidated**: update/mark `ARCHITECTURE.md` for review and return to `shape-work`.
- **Unrelated/new work**: capture under `PLAN.md` -> `Discovered work`; do not silently absorb it.

For a bug discovered mid-work: fix it now only when it blocks or invalidates the current slice. Otherwise capture it and continue.

## Close a block or slice

At a natural stop, user stop, or block boundary:

1. Persist verified discoveries in the appropriate authoritative document.
2. Update current slice checklist/status in `PLAN.md`.
3. Record actual time when available and useful; do not invent it.
4. Compare estimate vs actual only when both are known.
5. Mark stale/review-needed artifacts when implementation invalidates earlier assumptions.
6. Set one concrete `Next` action in `STATUS.md`.
7. If the slice is too large or its architecture has changed materially, return to `shape-work` instead of automatically extending the block.

Do not stop merely because a substep finished or a progress update could be given. Continue while the next action is clear, safe, and remains within the current slice and user scope.

## Slice completion

Mark a slice `done` only when its observable done conditions are satisfied and validated. A text-only claim of completion is not sufficient when runnable verification is available.

When the slice is complete, select the next `ready` slice only if the user's requested session/scope permits it; otherwise leave `STATUS.md` pointing to the next planning/execution action.
