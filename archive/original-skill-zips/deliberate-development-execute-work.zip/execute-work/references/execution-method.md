# Execution method and provenance

## Estimation and calibration

Primary public source:
- Joel Spolsky, Evidence Based Scheduling: https://www.joelonsoftware.com/2007/10/26/evidence-based-scheduling/

Use small enough units to make estimates meaningful, record actuals, and use personal historical error to improve forecasting. Keep developer estimates tied to concrete work rather than vague multi-week tasks.

This skillset does not adopt a requirement to enumerate every future implementation task up front; it estimates the current sufficiently understood slice.

## Time blocking

Public sources:
- Cal Newport, Focus Week: Take Control of Your Time: https://calnewport.com/focus-week-take-control-of-your-time/
- Time-Block Planner: https://www.timeblockplanner.com/
- Ryan Singer, Set Boundaries: https://basecamp.com/shapeup/1.2-chapter-03

Use a block to allocate attention intentionally. Re-plan the wider schedule when reality changes, but do not silently turn a block into an endlessly extending deadline.

The explicit `goal + stop/reassessment condition` used by this skillset is a derived cross-source rule, not a direct Newport prescription.

## TDD

Primary/supporting public sources:
- Kent Beck, Canon TDD: https://newsletter.kentbeck.com/p/canon-tdd
- Martin Fowler, Test Driven Development: https://martinfowler.com/bliki/TestDrivenDevelopment.html

Maintain a test list, select one runnable behavior, get the relevant test failing for the intended reason, make it pass, then inspect/refactor before continuing. Add discovered cases to the list rather than expanding the current step impulsively.

## Source tensions and chosen policies

### Refactoring

Beck allows refactoring to be optional and warns against over-refactoring; Fowler emphasizes that consistently skipping refactoring is a common TDD failure mode.

Policy: after green, inspect for a real refactoring opportunity. Refactor when it improves the design; do not refactor performatively.

### Re-planning

Newport recommends rebuilding the remaining day when disrupted; Shape Up treats the time box as a boundary rarely extended.

Policy: the broader calendar may be replanned, while the current block remains an explicit allocation. At its boundary, reassess/re-scope rather than silently extend.

### Bugs discovered mid-work

Spolsky favors fixing bugs promptly; Time-Block Planner favors capturing interruptions; Shape Up may treat QA finds as nice-to-haves by default.

Policy: fix a discovered bug now only when it blocks or invalidates the current slice. Otherwise capture it as discovered work.

### Hard-coding

Policy: faking an external/deferred dependency may support a vertical slice; faking the behavior under test does not satisfy the slice.

## Contrastive derived examples

Good estimate: `Validate empty and >100-character display names - 35 minutes`, after behavior and code path are understood.

Bad estimate: `Finish profile ticket - 2 hours.`

Good discovery handling: `Unrelated legacy bug found in component X -> add to Discovered work and continue.`

Bad discovery handling: `Since we're here, fix component X too.`
